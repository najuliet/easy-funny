var name = prompt("이름을 입력하세요.");
document.write("<h1>" + name + "님, 어서오세요</h1>");
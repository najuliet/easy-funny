var myVar = 100;
test();
document.write("myVar is " + myVar);

function test() { 			
	myVar = 50;
}